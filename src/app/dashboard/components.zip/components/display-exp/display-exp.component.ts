import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-exp',
  templateUrl: './display-exp.component.html',
  styleUrls: ['./display-exp.component.css']
})
export class DisplayExpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
